# Simple Beamer Theme

This is a **simple** and **clear** beamer theme for academic and scientific presentation.

## preview

![page1](img/0001.webp)
![page2](img/0002.webp)
![page3](img/0003.webp)
![page4](img/0004.webp)
![page5](img/0005.webp)
![page6](img/0006.webp)
![page9](img/0009.webp)
![page10](img/0010.webp)
